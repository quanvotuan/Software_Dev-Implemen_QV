#include "MyMemoryController.hpp"

int main() {
    // Your test case here
    return 0;
}