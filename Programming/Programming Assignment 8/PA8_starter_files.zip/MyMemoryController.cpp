#include "MyMemoryController.hpp"

/*
 * MyMemoryController constructor. Calls the MemoryController constructor
 *
 * Done for you. You should not modify this method.
*/
MyMemoryController::MyMemoryController(uint32_t base_address, uint32_t total_bytes) : 
    BaseMemoryController(base_address, total_bytes)
{
    this->write(base_address, word_to_bytes(total_bytes-8)); // Write the size of the block at the start and end of the block
    this->write(base_address+total_bytes-4, word_to_bytes(total_bytes-8)); // -8 because we need to account for the size of the metadata
    return;
}

/*
 * MyMemoryController destructor. Calls the MemoryController destructor
 *
 * Done for you. You should not modify this method.
*/
MyMemoryController::~MyMemoryController()
{
    return;
}

/*
 * TODO: Implement this method
 * 
 * Reads 'size' consecutive bytes from memory
 * We do not need to check if the addresses being read from are valid; it is the user's responsibility to ensure that
 * @param address: The starting address to read from
 * @param size: The number of bytes to read
 * @return: A vector of bytes read from memory in little endian order (byte at smallest address first)
*/
vector<int8_t> BaseMemoryController::read(uint32_t address, size_t size)
{
    return vector<int8_t>();
}


/*
 * TODO: Implement this method
 *
 * Writes each byte in data to memory
 * We do not need to check if the addresses being written to are valid; it is the user's responsibility to ensure that
 * @param address: The starting address to write to
 * @param data: A vector of bytes to write to memory in little endian order (byte at smallest address first)
*/
void BaseMemoryController::write(uint32_t address, vector<int8_t> data)
{
    return;
}

/*
 * TODO: Implement this method
 *
 * Allocates a block of memory of the given size at the smallest possible address. Returns 0 if the allocation fails.
 * Should write the negative size of the block at the start and end of the block
 * Remember the returned pointer is the first address the user can write to,
 * which is not the same as the start of the block of memory you allocate.
 * @param size: The number of bytes to allocate
 * @return: A pointer to the start of the allocated block of memory
*/
uint32_t BaseMemoryController::malloc(size_t size)
{
    return 0;
}

/*
 * TODO: Implement this method
 *
 * Frees a block of memory at the given pointer
 * If the pointer is 0, this method should do nothing.
 * Should write the positive size of the block at the start and end of the block
 * You do not need to check if the pointer being freed is valid; it is the user's responsibility to ensure that
 * However, you should check if the pointer is within the memory system's range and return straight away if it is not
 * Remember that the pointer passed in is the first address the user can write to,
 * which is not the same as the start of the block of memory you allocated.
 * Remember to merge the new free block with the next free block if possible
 * @param ptr: The pointer to the block of memory to free
*/
void BaseMemoryController::free(uint32_t ptr)
{
    return;
}

/*
 * TODO: Implement this method
 *
 * Reallocates a block of memory of the given size at the given pointer. Returns 0 if the allocation fails.
 * If the pointer is 0, this method should behave like malloc.
 * If the size is 0, this method should behave like free (and return 0).
 * If there is enough space to expand the block at the given pointer, you must do so.
 * Remember to copy the data from the old block of memory to the new block of memory if the pointer changes.
 * Remember the returned pointer is the first address the user can write to,
 * which is not the same as the start of the block of memory you allocated.
 * Remember to merge the new free block with the next free block if possible
 * You do not need to check if the pointer being reallocated is valid; it is the user's responsibility to ensure that
 * @param ptr: The pointer to the block of memory to reallocate
 * @param size: The new size of the block of memory
*/
uint32_t BaseMemoryController::realloc(uint32_t ptr, size_t new_size)
{
    return ptr;
}
