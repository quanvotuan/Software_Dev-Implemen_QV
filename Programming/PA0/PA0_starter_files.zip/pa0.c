// ECE 312 PA0
// <Your Name Here>
// <Your EID Here>
// Slip days used: 0
// Fall 2023
#include "pa0.h"

double computeSquare(double x) {
    
	//TODO: Your code here
	return 0;
}

int gcd(int y, int z) {
    
	//TODO: Your code here
	return 0;
}

//Given function to be used in findSumPrimes
//Returns 1 if num is prime and 0 if num is not prime
int isPrime(int num) {

    if (num <= 1) return 0;
    if (num % 2 == 0 && num > 2) return 0;
    for(int i = 3; i< num / 2; i+= 2)
    {
        if( num % i == 0 ){
            return 0;
        }
    }
    return 1;
}

int findSumPrimes(int x) {
    
	//TODO: Your code here
	return 0;
}

