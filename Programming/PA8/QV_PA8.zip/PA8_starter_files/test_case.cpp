#include "MyMemoryController.hpp"

#define NUM_BYTES 10

int main() {
    MyMemoryController* mem = new MyMemoryController(0x2000, 64);

    //mem->print_heap(0x2000, 0x2040);
    int32_t test1 = mem->read_full_word(0x2000);
    std::cout << test1 << std::endl;
    std::cout << "--------------" << std::endl;


    uint32_t  mem1 = mem->malloc(11);
//    mem->print_heap(0x2000, 0x2040);
//    std::cout << "----------------------------------" << std::endl;

    uint32_t  mem2 = mem->malloc(20);
//    mem->print_heap(0x2000, 0x2040);
//    std::cout << "----------------------------------" << std::endl;

    mem1 = mem->realloc(mem1, 15);
//    mem->print_heap(0x2000, 0x2040);
//    std::cout << "----------------------------------" << std::endl;

    mem2 = mem->realloc(mem2, 24);
//    mem->print_heap(0x2000, 0x2040);
//    std::cout << "----------------------------------" << std::endl;

    mem->free(mem1);
//    mem->print_heap(0x2000, 0x2040);
//    std::cout << "----------------------------------" << std::endl;

    mem->free(mem2);
    mem->print_heap(0x2000, 0x2040);
//    std::cout << "----------------------------------" << std::endl;

    std::cout << "--------------" << std::endl;
    int32_t end_test1 = mem->read_full_word(0x203c);
    std::cout << std::dec << end_test1 << std::endl;

    assert(test1 == end_test1); // Check whether the total bytes after free == original heap size
}
